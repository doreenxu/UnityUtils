﻿using UnityEngine;
using System.Collections;

public enum GP_RTM_PackageType  {

	RELIABLE = 0, 
	UNRELIABLE = 1
}
