﻿using UnityEngine;
using System.Collections;

public enum GP_RTM_RoomStatus {

	ROOM_VARIANT_DEFAULT = -1,
	ROOM_STATUS_INVITING = 0,
	ROOM_STATUS_AUTO_MATCHING = 1,
	ROOM_STATUS_CONNECTING = 2,
	ROOM_STATUS_ACTIVE = 3

}
