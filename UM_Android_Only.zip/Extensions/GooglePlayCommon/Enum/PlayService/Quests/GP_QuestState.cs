﻿using UnityEngine;
using System.Collections;

public enum GP_QuestState  {

	STATE_UPCOMING = 1,
	STATE_OPEN = 2,
	STATE_ACCEPTED = 3,
	STATE_COMPLETED = 4,
	STATE_EXPIRED = 5,
	STATE_FAILED = 6

}
