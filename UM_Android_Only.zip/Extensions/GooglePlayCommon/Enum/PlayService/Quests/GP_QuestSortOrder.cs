﻿using UnityEngine;
using System.Collections;

public enum GP_QuestSortOrder {

	SORT_ORDER_RECENTLY_UPDATED_FIRST = 0,
	SORT_ORDER_ENDING_SOON_FIRST = 1
}
