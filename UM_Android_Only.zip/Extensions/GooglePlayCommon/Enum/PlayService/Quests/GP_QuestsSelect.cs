﻿using UnityEngine;
using System.Collections;

public enum GP_QuestsSelect  {

	SELECT_UPCOMING = 1,
	SELECT_OPEN = 2,
	SELECT_ACCEPTED = 3,
	SELECT_COMPLETED = 4,
	SELECT_EXPIRED = 5,
	SELECT_FAILED = 6,
	SELECT_COMPLETED_UNCLAIMED = 101,
	SELECT_ENDING_SOON = 102
}
