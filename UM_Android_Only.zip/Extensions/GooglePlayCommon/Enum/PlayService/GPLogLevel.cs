﻿using UnityEngine;
using System.Collections;

public enum GPLogLevel  {

	VERBOSE = 0,
	INFO = 1,
	WARNING = 2,
	ERROR = 3

}
