﻿using UnityEngine;
using System.Collections;

public enum GP_TBM_MatchStatus  {

	MATCH_STATUS_AUTO_MATCHING = 0,
	MATCH_STATUS_ACTIVE = 1,
	MATCH_STATUS_COMPLETE = 2,
	MATCH_STATUS_EXPIRED = 3,
	MATCH_STATUS_CANCELED = 4

}
