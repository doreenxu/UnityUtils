﻿using UnityEngine;
using System.Collections;

public enum GP_TBM_MatchesSortOrder  {

	SORT_ORDER_MOST_RECENT_FIRST = 0,
	SORT_ORDER_SOCIAL_AGGREGATION = 1
}
