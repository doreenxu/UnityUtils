﻿using UnityEngine;
using System.Collections;

public enum GP_TBM_MatchTurnStatus {

	MATCH_TURN_STATUS_INVITED = 0,
	MATCH_TURN_STATUS_MY_TURN = 1,
	MATCH_TURN_STATUS_THEIR_TURN = 2,
	MATCH_TURN_STATUS_COMPLETE = 3,
}
