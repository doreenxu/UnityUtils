﻿using UnityEngine;
using System.Collections;

public enum AdroidActivityResultCodes  {

	RESULT_OK = -1,
	RESULT_CANCELED = 0,
	RESULT_FIRST_USER = 1

}
