﻿using UnityEngine;
using System.Collections;

public class GP_ScoreResult : GooglePlayResult {

	public GPScore score;
	
	public GP_ScoreResult(string code):base(code) {
		
	}
}
