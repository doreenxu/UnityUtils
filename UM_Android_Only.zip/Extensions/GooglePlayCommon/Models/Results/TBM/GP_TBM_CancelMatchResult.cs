﻿using UnityEngine;
using System.Collections;

public class GP_TBM_CancelMatchResult : GooglePlayResult {

	public string MatchId;

	public GP_TBM_CancelMatchResult(string code):base(code) {
		
	}
}
