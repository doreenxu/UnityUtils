﻿using UnityEngine;
using System.Collections;

public class GP_TBM_MatchInitiatedResult : GooglePlayResult {

	public GP_TBM_Match Match;
	
	public GP_TBM_MatchInitiatedResult(string code):base(code) {
		
	}
}
