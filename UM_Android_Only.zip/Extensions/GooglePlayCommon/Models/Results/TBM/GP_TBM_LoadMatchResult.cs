﻿using UnityEngine;
using System.Collections;

public class GP_TBM_LoadMatchResult  : GooglePlayResult {
	
	public GP_TBM_Match Match;
	
	public GP_TBM_LoadMatchResult(string code):base(code) {
		
	}


}
