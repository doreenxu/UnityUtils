﻿using UnityEngine;
using System.Collections;

public class AndroidGameActivityResult {

	public GP_GamesActivityResultCodes code;
}
