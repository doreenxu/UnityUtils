﻿using UnityEngine;
using System.Collections;

public enum AN_InAppType {
	Consumable,
	NonConsumable,
	Subscription
}
