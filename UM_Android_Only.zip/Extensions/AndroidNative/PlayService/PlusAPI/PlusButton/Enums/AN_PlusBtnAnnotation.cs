﻿using UnityEngine;
using System.Collections;

public enum AN_PlusBtnAnnotation {

	ANNOTATION_NONE = 0,
	ANNOTATION_BUBBLE = 1,
	ANNOTATION_INLINE = 2
}
