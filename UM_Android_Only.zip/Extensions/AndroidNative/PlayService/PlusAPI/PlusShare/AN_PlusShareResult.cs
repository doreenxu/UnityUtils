﻿using UnityEngine;
using System.Collections;

public class AN_PlusShareResult : AN_Result {

	public AN_PlusShareResult(bool IsResultSucceeded) : base(IsResultSucceeded) {

	}

}
