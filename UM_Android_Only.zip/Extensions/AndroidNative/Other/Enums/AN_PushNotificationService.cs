﻿using UnityEngine;
using System.Collections;

public enum AN_PushNotificationService  {
	Google,
	OneSignal,
	Parse

}
