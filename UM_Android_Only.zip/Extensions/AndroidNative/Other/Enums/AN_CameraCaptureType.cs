﻿using UnityEngine;
using System.Collections;

public enum AN_CameraCaptureType  {

	Thumbnail = 0,
	FullSizePhoto = 1
}
