﻿using UnityEngine;
using System.Collections;

public enum AN_PermissionState  {

	PERMISSION_GRANTED = 0,
	PERMISSION_DENIED = -1
}
