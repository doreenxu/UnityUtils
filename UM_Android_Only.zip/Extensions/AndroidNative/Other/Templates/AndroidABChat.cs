﻿using UnityEngine;
using System.Collections;

public class AndroidABChat {

	public string name, type;
}
