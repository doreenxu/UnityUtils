﻿using UnityEngine;
using System.Collections;

public class AndroidABAddress {

	public string poBox;
	public string street;
	public string city;
	public string state;
	public string postalCode;
	public string country;
	public string type;
}
