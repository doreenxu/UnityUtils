﻿using UnityEngine;
using System.Collections;

public enum AN_SoomlaEventType  {
	SOOMLA_EVENT_STARTED = 1,
	SOOMLA_EVENT_FINISHED = 2,
	SOOMLA_EVENT_CNACELED = 3,
	SOOMLA_EVENT_FAILED = 4
}
