﻿using UnityEngine;
using System.Collections;

public enum AN_SoomlaSocialProvider  {
	FACEBOOK = 1,
	TWITTER = 2,
	GOOGLE = 3,
	INSTAGRAM = 4
}
