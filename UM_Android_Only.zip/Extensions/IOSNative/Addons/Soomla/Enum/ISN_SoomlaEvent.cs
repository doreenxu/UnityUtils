﻿using UnityEngine;
using System.Collections;

public enum ISN_SoomlaEvent  {

	STARTED = 1,
	FINISHED = 2,
	CANCELLED = 3,
	FAILED = 4
}
