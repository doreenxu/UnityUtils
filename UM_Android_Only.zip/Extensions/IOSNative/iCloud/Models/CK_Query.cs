﻿using UnityEngine;
using System.Collections;

public class CK_Query  {


}

