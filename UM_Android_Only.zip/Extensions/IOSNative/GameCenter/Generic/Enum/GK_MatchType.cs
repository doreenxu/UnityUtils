﻿using UnityEngine;
using System.Collections;

public enum GK_MatchType  {

	TurnBased = 0,
	RealTime = 1
}
