﻿using UnityEngine;
using System.Collections;

public enum MP_MusicShuffleMode  {
	Default = 0,
	Off = 1,
	Songs = 2,
	Albums = 3
}
