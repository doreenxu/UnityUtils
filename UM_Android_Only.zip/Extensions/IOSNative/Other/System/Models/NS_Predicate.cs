﻿using UnityEngine;
using System.Collections;

public class NS_Predicate  {


}

