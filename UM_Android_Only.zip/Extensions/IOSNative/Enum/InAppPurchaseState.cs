﻿using UnityEngine;
using System.Collections;

public enum InAppPurchaseState {
	Purchased,
	Failed,
	Deferred,
	Restored
}
