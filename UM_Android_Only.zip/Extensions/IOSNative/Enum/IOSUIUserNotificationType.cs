﻿using UnityEngine;
using System.Collections;

public class IOSUIUserNotificationType  {

	public const int Alert = 4;
	public const int Sound = 2;
	public const int Badge = 1;
}
