﻿using UnityEngine;
using System.Collections;



[System.Serializable]
public class GAPlatfromBound  {

	public RuntimePlatform platfrom;
	public int profileIndex;
	public int profileIndexTestMode;
}
