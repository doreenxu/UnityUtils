﻿using UnityEngine;
using System.Collections;

public enum GoogleAnalyticsHitType  {
	PAGEVIEW,
	APPVIEW,
	EVENT,
	TRANSACTION,
	ITEM,
	SOCIAL,
	EXCEPTION,
	TIMING,
	SCREENVIEW
}
