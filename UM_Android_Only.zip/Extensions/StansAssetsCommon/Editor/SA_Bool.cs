﻿using UnityEngine;
using System.Collections;

public enum SA_Bool  {
	Enabled,
	Disabled
}