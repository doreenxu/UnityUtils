﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


[System.Serializable]
public class GADTestDevice  {
	public string Name = "[New Test Device]";
	public string ID = "put your device id here";
	public bool IsOpen = false;
}
