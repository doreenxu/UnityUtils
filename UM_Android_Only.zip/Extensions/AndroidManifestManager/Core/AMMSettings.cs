﻿using UnityEngine;
using System.Collections;

public class AMMSettings  {


	public const string VERSION_NUMBER = "1.5";
}
